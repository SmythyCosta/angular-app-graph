# AppGraph

Aplicação para uso de Grafos, lib @swimlane/ngx-graph




## references
https://swimlane.github.io/ngx-graph/#introduction

https://stackblitz.com/edit/ngx-graph-simple-example?file=package.json

https://stackoverflow.com/questions/53539975/how-to-start-with-ngx-graph-for-angular-7




## app custom
https://github.com/rat17sri/ngx-graph-angular

https://rat17sri.github.io/ngx-graph-angular/