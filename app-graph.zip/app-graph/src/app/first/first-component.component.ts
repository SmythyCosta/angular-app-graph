import { Component, OnInit } from '@angular/core';
//import { NgxGraphModule } from '@swimlane/ngx-graph';

@Component({
  selector: 'app-first-component',
  templateUrl: './first-component.component.html'
})
export class FirstComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
