import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { AppRoutingModule } from './app.routing.module'; 

import { BrowserAnimationsModule } from '@angular/platform-browser/animations';


import { AppComponent } from './app.component';
import { FirstComponent } from './first/first-component.component';
import { SecondComponent } from './second/second-component.component';
import { NgxGraphModule } from '@swimlane/ngx-graph';
import { ThreeComponent } from './three/three-component.component';
import { FourComponent } from './four/four-component.component'; 




@NgModule({
  declarations: [
    AppComponent,
    FirstComponent,
    SecondComponent,
    ThreeComponent,
    FourComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    NgxGraphModule,
    BrowserAnimationsModule
  ],
  exports: [FirstComponent, SecondComponent],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
